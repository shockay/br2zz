package reflection.interfacea;

public interface A {
	void f();
}
