package util;

public class Print {

	public static void print(String arg){
		System.out.println(arg);
		//return arg;
	}
}
